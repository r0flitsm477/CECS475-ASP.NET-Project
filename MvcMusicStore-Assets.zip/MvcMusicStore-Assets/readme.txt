These are the items you'll need to complete the MVC Music Store tutorial. You can read more about the MVC Music Store at http://mvcmusicstore.codeplex.com

These assets are for the v3 release, updated for the ASP.NET MVC 3 Tools Update.

The Content directory contains a stylesheet and images (you'll use these in section 3)
The Data directory contains a database (only used if you won't be using SQL Server CE)
The Code directory contains code for an AccountController (you'll add these in section 7)